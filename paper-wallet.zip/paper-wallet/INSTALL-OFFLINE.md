# Putting it on the home screen without hosting it

Use `paper-wallet-offline.html` — one file, no server, no manifest, no service worker.

## Before you transfer it

Open the file in any text editor and edit the config block near the top:

```js
const CONFIG = {
  pin:  '',        // your 6-digit passcode, e.g. '204815'
  cash: 14.41,
  sol:  0.00143
};
```

This matters because the offline route has no saved storage — the app resets to these values each launch. Set `pin` to the code you want, or leave it blank and the app asks you to create one each time you open it.

## 1. Get the file onto the iPhone

AirDrop it from your Mac, or email it to yourself. Tap it → Share → **Save to Files** → **On My iPhone**. Remember the folder.

## 2. Build the shortcut

1. Open the **Shortcuts** app → **+** → **Add Action**
2. Search **Get File** → add it
   - Tap **File Path**, turn **Show Document Picker** off, and point it at the file (Service: On My iPhone, then the path, e.g. `Shortcuts/paper-wallet-offline.html`)
3. **Add Action** again → search **Quick Look** → add it
4. Tap the name at the top, rename it "Paper Wallet"
5. Run it once to check the app opens

## 3. Add it to the home screen

In the shortcut, tap the share icon → **Add to Home Screen** → tap the icon thumbnail to choose a glyph and colour → **Add**.

You now have an icon that opens the app with no browser, no internet, no hosting.

## What you give up

- **No saved state.** The passcode and balance come from the config block each launch, so changes made inside the app don't survive closing it.
- **A Quick Look bar at the top** with a Done button — it isn't quite the seamless fullscreen of a real installed app.
- **A brief Shortcuts flash** when it launches.

## If you want the polished version instead

The hosted route (`index.html` + `manifest.json` + `sw.js`) gives true fullscreen, a saved passcode, a saved balance, and offline caching. It only needs a URL once — drag the folder onto app.netlify.com/drop, install from Safari, and the site can sit there unlisted forever.
