# Paper Wallet

A practice wallet app. The balance is whatever you set — no real funds, no wallet connection, no network calls. Market data, charts and the countdown are simulated.

## Put it on your phone

The app needs to be served over HTTPS to install (a `file://` page can't register a service worker).

**Fastest option — Netlify Drop**
1. Go to app.netlify.com/drop
2. Drag this whole folder in
3. Open the URL it gives you on your phone
4. iPhone: Share → Add to Home Screen. Android: menu → Install app.

Any static host works the same way: GitHub Pages, Cloudflare Pages, Vercel, or a folder on your own server.

**Test locally first**
```
python3 -m http.server 8000
```
then open http://localhost:8000

## Getting in

First launch asks you to create a 6-digit passcode, then re-enter it. After that the app locks on every launch, and re-locks if you leave it for more than 15 seconds.

Side menu → **Settings** to change the passcode, or **Lock now** to lock immediately.

Note: this is practice-app security, not a vault. The passcode sits in the browser's local storage on the device. Don't put anything real behind it.

## Using it

- Tap the big balance (or the purple **+**) to set cash and SOL.
- Quick buttons fill $100 / $1k / $10k / $100k.
- Your balance is saved on the device and survives a restart.
- Tap the avatar top-left for the side menu.

## Files

| File | Purpose |
|---|---|
| `index.html` | The entire app — markup, styles, logic |
| `manifest.json` | Name, icons, standalone display mode |
| `sw.js` | Offline caching |
| `icon-192.png`, `icon-512.png` | Home screen icons |

## Changing things

Sized for a 390 x 844pt screen (iPhone 12/13/14) with safe-area padding, and the layout scales to other phones. Everything is in `index.html`. Prices and token lists are in the `trending` and `exploreTrending` arrays; `SOL_PRICE` sets the SOL conversion rate. Colours are CSS variables at the top of the `<style>` block.
